import { HTTP } from '@ionic-native/http';

export default class WatsonChat {

    url: string;
    iam_apikey: string;
    workspaceId: string;

    http = new HTTP();

    init(url, iam_apikey, workspaceId) {
        this.url = url;
        this.iam_apikey = iam_apikey;
        this.workspaceId = workspaceId;
    }

    sendMessage(messages = [], input, callback) {
        messages.push(Object.assign({}, { m: input, isWatson: false }));
        var obj = {};
        obj["workspace_id"] = this.workspaceId;
        obj["input"] = JSON.parse(JSON.stringify({ text: input }));

        this.http.useBasicAuth('apikey', this.iam_apikey);
        this.http.setDataSerializer('json');
        this.http.post(`${this.url}/v1/workspaces/${this.workspaceId}/message?version=2018-09-20`, obj, null).then((res) => {
            const msg = JSON.parse(res.data).output.text[0];
            messages.push(Object.assign({}, { m: msg, isWatson: true }));
            return callback(null, messages);
        }).catch((err) => {
            alert('error ' + err);
            messages.push(Object.assign({}, { m: 'Bot is out of service! Try again later!', isWatson: true }));
            return callback(null, messages);
        });
    }
}