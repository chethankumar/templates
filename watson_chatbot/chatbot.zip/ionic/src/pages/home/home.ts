import { Component, Renderer, NgZone } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ChatbotPage } from "../chatbot/chatbot";

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController) {

  }

    home_Button_1473_clickHandler() {
        this.navCtrl.push( ChatbotPage, {
                data: {"a":"a"}
              });
    }
}
