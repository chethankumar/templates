import { Component,Renderer,NgZone } from '@angular/core';
import { NavController,ModalController } from 'ionic-angular';
import WatsonChat from "../../componentScripts/chat";

@Component({
  selector: 'page-chatbot',
  templateUrl: 'chatbot.html'
})
export class ChatbotPage {

  constructor(public navCtrl: NavController, renderer: Renderer, private zone: NgZone) {
      this.watsonChat.init(this.url,this.iam_apikey,this.workspaceId);

  }

    messages = [];
    input: any;
    watsonChat = new WatsonChat();

    message() {
        this.watsonChat.sendMessage(this.messages, this.input,(err,msgs)=>{ this.zone.run(() => { this.messages = msgs; }); });this.input='';
    }
}
